<?php
/*
 * Utilizzare i Widget per le 4 colonne e la pagina "Dettagli" del backend per i recapiti e url mappa
 *
 */
?>

    </main>
    
    <footer id="footer" class="u-background-80" style="background-color: #00264d!important">
        <div class="container">
            
			
			
           <section>
                <div class="row">
                    <?php   if (is_active_sidebar('footer-colonne')) { dynamic_sidebar('footer-colonne'); } ?>
                </div>
            </section>
           
			<section>
                <div class="row">
                    
                    <div class="col-12 col-md-6 col-lg-3" style="padding-top:20px">
						<a href="http://www.agid.gov.it/" target="_blank"><img src="https://monitoraggiopianotriennale.italia.it/wp-content/uploads/2021/03/AgID_bianco.png" alt="logo agid"></a>
                    </div>
                    
                    <div class="col-12 col-md-6 col-lg-3">
                        
                    </div>
                    
                    <div class="col-12 col-md-6 col-lg-3">
                    </div>
					
					

                    <div class="col-12 col-md-6 col-lg-3">
                        <h3 class="socialfooter"><?php echo __('Follow us on','italiawp2'); ?></h3>
						
						
						<a  target="_blank" class="social-icon"
						   aria-label="<?php echo __('Link to external site','italiawp2'); ?> - Facebook"
						   href="https://www.facebook.com/AgIDGovIT/">
							<img src="https://monitoraggiopianotriennale.italia.it/wp-content/uploads/2021/03/icon_facebook.png" width="64px" alt="logo facebook">   
							<span class="hidden"><?php echo __('Follow us on','italiawp2'); ?> Facebook</span>
						</a>
						
						<a  target="_blank" class="social-icon"
						   aria-label="<?php echo __('Link to external site','italiawp2'); ?> - Twitter"
						   href="https://twitter.com/AgidGov">
							<img src="https://monitoraggiopianotriennale.italia.it/wp-content/uploads/2021/03/icon_twitter.png" width="64px" alt="logo twitter">   
							<span class="hidden"><?php echo __('Follow us on','italiawp2'); ?> Twitter</span>
						</a>
						
						<a  target="_blank" class="social-icon"
						   aria-label="<?php echo __('Link to external site','italiawp2'); ?> - Youtube"
						   href="https://www.youtube.com/channel/UCxJmOWf__YcLgB19gy5dGQQ">
							<img src="https://monitoraggiopianotriennale.italia.it/wp-content/uploads/2021/03/icon_youtube.png" width="64px" alt="logo youtube">   
							<span class="hidden"><?php echo __('Follow us on','italiawp2'); ?> Youtube</span>
						</a>
						
						<a  target="_blank" class="social-icon"
						   aria-label="<?php echo __('Link to external site','italiawp2'); ?> - Medium"
						   href="https://medium.com/@AgidGov">
							<img src="https://monitoraggiopianotriennale.italia.it/wp-content/uploads/2021/03/icon_medium.png" width="64px" alt="logo medium">   
							<span class="hidden"><?php echo __('Follow us on','italiawp2'); ?> Medium</span>
						</a>
                        
                   
                    </div>
                </div>
            </section>
			
            <section class="postFooter clearfix">
                <h3 class="sr-only"><?php echo __('Useful Links Section','italiawp2'); ?></h3>                
                
                <?php if(get_option('dettagli-id-privacy')!=""): ?>
                    <a href="<?php echo get_permalink(get_option('dettagli-id-privacy')); ?>" title="<?php echo __('Privacy policy','italiawp2'); ?>"><?php echo __('Privacy','italiawp2'); ?></a> |
                <?php endif; ?>
                <?php if(get_option('dettagli-id-cookie')!=""): ?>
                    <a href="<?php echo get_permalink(get_option('dettagli-id-cookie')); ?>" title="<?php echo __('Cookie policy','italiawp2'); ?>"><?php echo __('Cookie policy','italiawp2'); ?></a> |
                <?php endif; ?>
                <?php if(get_option('dettagli-id-notelegali')!=""): ?>
                    <a href="<?php echo get_permalink(get_option('dettagli-id-notelegali')); ?>" title="<?php echo __('Legal notices','italiawp2'); ?>"><?php echo __('Legal notices','italiawp2'); ?></a> |
                <?php endif; ?>
                <?php if(get_option('dettagli-id-contatti')!=""): ?>
                    <a href="<?php echo get_permalink(get_option('dettagli-id-contatti')); ?>" title="<?php echo __('Contacts','italiawp2'); ?>"><?php echo __('Contacts','italiawp2'); ?></a> |
                <?php endif; ?>
                <?php if(get_option('dettagli-link-accessibilita')!=""): ?>
                    <a target="_blank" href="<?php echo get_option('dettagli-link-accessibilita'); ?>" title="<?php echo __('Accessibility','italiawp2'); ?>"><?php echo __('Accessibility','italiawp2'); ?></a> |
                <?php endif; ?>
               
                
                <br>
                <?php if(is_active_sidebar('credits')) dynamic_sidebar('credits'); ?>

            </section>
        </div>
    </footer>
    
</div>

<div id="topcontrol" class="topcontrol u-background-80" title="<?php echo __('Go up','italiawp2'); ?>">
  <svg class="icon">
    <use xlink:href="<?php bloginfo('template_url'); ?>/static/img/bootstrap-italia.svg#it-collapse"></use>
  </svg>
</div>

<?php wp_footer(); ?>

<?php
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if ( is_plugin_active( 'albo-pretorio-on-line/AlboPretorio.php' ) ) { ?>
    <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
<?php } ?>
    
    <script src="<?php bloginfo('template_url'); ?>/static/js/popper.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/static/js/bootstrap-italia.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/static/js/tema.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/static/js/jquery-ui.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/static/js/i18n/datepicker-it.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/static/js/owl.carousel.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/inc/magnific-popup/jquery.magnific-popup.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/inc/scripts.js"></script>

<script>
$('#collapseDiv1').on('shown.bs.collapse', function () {$(window).trigger('resize');})
$('#collapseDiv2').on('shown.bs.collapse', function () {$(window).trigger('resize');})
$('#collapseDiv3').on('shown.bs.collapse', function () {$(window).trigger('resize');})
$('#collapseDiv4').on('shown.bs.collapse', function () {$(window).trigger('resize');})
$('#collapseDiv5').on('shown.bs.collapse', function () {$(window).trigger('resize');})
$('#collapseDiv6').on('shown.bs.collapse', function () {$(window).trigger('resize');})
$('#collapseDiv7').on('shown.bs.collapse', function () {$(window).trigger('resize');})
$('#collapseDiv8').on('shown.bs.collapse', function () {$(window).trigger('resize');})
$('#collapseDiv9').on('shown.bs.collapse', function () {$(window).trigger('resize');})
$('#collapseDiv10').on('shown.bs.collapse', function () {$(window).trigger('resize');})
</script>
</body>
</html>
