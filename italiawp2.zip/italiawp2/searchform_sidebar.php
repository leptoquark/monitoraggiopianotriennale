<div class="form-group">
    <label class="sr-only"><?php echo __('Search for Topics','italiawp2'); ?></label>
        <button type="submit" class="ico-sufix">
            <svg class="icon"><use xlink:href="<?php bloginfo('template_url'); ?>/static/img/ponmetroca.svg#ca-search"></use></svg>
        </button>
</div>
