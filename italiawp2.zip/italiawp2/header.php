<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <?php if(get_option('custom-meta-keywords')!=""): ?>
    <meta name="keywords" content="<?php echo get_option('custom-meta-keywords'); ?>">
    <?php endif; ?>
    
    <?php if(get_option('custom-meta-description')!=""): ?>
    <meta name="description" content="<?php echo get_option('custom-meta-description'); ?>">
    <?php else: ?>
    <meta name="description" content="<?php echo get_bloginfo('description'); ?>">
    <?php endif; ?>
    
    <script>
        window.__PUBLIC_PATH__ = "<?php bloginfo('template_url'); ?>/static/fonts";
        theme_directory = "<?php echo get_template_directory_uri() ?>";
    </script>

    <?php if (is_front_page()) { ?>
        <title><?php bloginfo('name'); ?></title>
    <?php } else { ?>
        <title><?php bloginfo('name'); ?><?php wp_title(); ?></title>
    <?php } ?>

    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
    
    <?php $custom_logo_id = get_theme_mod( 'custom_logo' );
          $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' ); ?>
    
    <link rel="icon" type="image/png" href="<?php echo esc_url($logo[0]); ?>">
    
    <link href="<?php bloginfo('template_url'); ?>/static/css/bootstrap-italia.min.css" rel="stylesheet" type="text/css">
    <link href="<?php bloginfo('template_url'); ?>/static/css/owl.carousel.min.css" rel="stylesheet" type="text/css">
    <link href="<?php bloginfo('template_url'); ?>/static/css/owl.theme.default.min.css" rel="stylesheet" type="text/css">
    <link href="<?php bloginfo('template_url'); ?>/static/css/home.css" rel="stylesheet" type="text/css">
    <link href="<?php bloginfo('template_url'); ?>/static/css/sezioni.css" rel="stylesheet" type="text/css">
    <link href="<?php bloginfo('template_url'); ?>/static/css/interne.css" rel="stylesheet" type="text/css">
    <link href="<?php bloginfo('template_url'); ?>/static/css/jquery-ui.css" rel="stylesheet" type="text/css">
    <link href="<?php bloginfo('template_url'); ?>/static/css/tema.css" rel="stylesheet" type="text/css">
    <link href="<?php bloginfo('template_url'); ?>/inc/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">
    <link href="<?php bloginfo('template_url'); ?>/inc/gutenberg.css" rel="stylesheet" type="text/css">

    <?php wp_head(); ?>

    <!-- HTML5shim per Explorer 8 -->
    <script src="<?php bloginfo('template_url'); ?>/static/js/modernizr.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/static/js/jquery.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/inc/pre-scripts.js"></script>    
	
	<script 
			src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js">
	</script>
	 <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
	<script>
		var jsonResponse
	</script>

<script async src="https://www.googletagmanager.com/gtag/js?id=G-11MDBB15LP"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-11MDBB15LP');
</script>

	<!-- script per la creazione dei grafici gauge personalizzati -->
	<script>
		function createGraph(title, sheetNumber, titleColumn, color1, color2, borWidth, borColor) {
            console.log('creo grafico ' + title + ' per titleColumn = ' + titleColumn)
            function BuildChart(labels, values, chartTitle) {
                var data = {
                    labels: labels,
                    datasets: [{
                        label: chartTitle,
                        data: values,
                        backgroundColor: [color1, color2],
						borderWidth: borWidth,
						borderColor: borColor
                    }],
                };

                var ctx = document.getElementById(title).getContext('2d');
                var myChart = new Chart(ctx, {
                    type: 'doughnut',
                    data: data,
                    options: {
                        title: {
                            display: true,
                            text: values[0] + '%',
                            position: 'bottom',
                            fontSize: 48
                        },
                        legend: {
                            display: false,
                        },
                        responsive: true,
                        maintainAspectRatio: false,
                        rotation: 1 * Math.PI,
                        circumference: 1 * Math.PI,
                    }
                });

                return myChart;
            }
            if (jsonResponse === undefined) {
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function () {
                    if (this.readyState == 4 && this.status == 200) {
                        var json = JSON.parse(this.response);
                        console.log("leggo gsheet = " + json);
                        jsonResponse = json

                        var dataIndexStart = -1

                        for (let i = 0; i < json.feed.entry.length; i++) {
                            if (json.feed.entry[i].gs$cell.$t.toUpperCase() === titleColumn.toUpperCase()) {
                                dataIndexStart = i
                                break
                            }
                        }

                        // Map json labels  back to values array

                        var labels = []
                        labels.push(json.feed.entry[0].gs$cell.$t)
                        labels.push(json.feed.entry[1].gs$cell.$t)
                        var values = []
                        values.push(json.feed.entry[dataIndexStart + 1].gs$cell.$t)
                        values.push(json.feed.entry[dataIndexStart + 2].gs$cell.$t)

                        BuildChart(labels, values, "Titolo");
                    }
                };
                xhttp.open("GET", "https://spreadsheets.google.com/feeds/cells/1UD7xoNFjwt8ynjRG-j7hDrml87Yqk8Mb2ayrnJJ76sw/" + sheetNumber + "/public/full?alt=json", false);
                xhttp.send();
            } else {
                var json = jsonResponse
                var dataIndexStart = -1

                for (let i = 0; i < json.feed.entry.length; i++) {
                    if (json.feed.entry[i].gs$cell.$t.toUpperCase() === titleColumn.toUpperCase()) {
                        dataIndexStart = i
                        break
                    }
                }

                var labels = []
                labels.push(json.feed.entry[0].gs$cell.$t)
                labels.push(json.feed.entry[1].gs$cell.$t)
                var values = []
                values.push(json.feed.entry[dataIndexStart + 1].gs$cell.$t)
                values.push(json.feed.entry[dataIndexStart + 2].gs$cell.$t)

                BuildChart(labels, values, "Titolo");
            }


        }
	
	</script>
	
	
	<script>
		// this script is written by yazzz https://stackoverflow.com/a/35819751/9894532
		$(function() {
			$(".wrapper").each(function() {
				var $wrap = $(this);
				function iframeScaler(){
					var wrapWidth = $wrap.width(); // width of the wrapper
					var wrapHeight = $wrap.height();
					console.log("wrapHeight = " + wrapHeight)
					console.log("wrapWidth = " + wrapWidth)
					var childWidth = $wrap.children("iframe").width(); // width of child iframe
					var childHeight = $wrap.children("iframe").height(); // child height
					var wScale = wrapWidth / childWidth;
					var hScale = wrapHeight / childHeight;
					var scale = Math.min(wScale,hScale);  // get the lowest ratio
					$wrap.children("iframe").css({"transform": "scale("+scale+")", "transform-origin": "left top" });  // set scale
				};
				$(window).on("resize", iframeScaler);
				$(document).ready( iframeScaler);
			});
		});
		
		$(function() {
			$(".wrapper_card").each(function() {
				var $wrap = $(this);
				function iframeScaler(){
					var wrapWidth = $wrap.width() * 1.5; // width of the wrapper
					var wrapHeight = $wrap.height() * 1.5;
					console.log("wrapHeight = " + wrapHeight)
					console.log("wrapWidth = " + wrapWidth)
					var childWidth = $wrap.children("iframe").width(); // width of child iframe
					var childHeight = $wrap.children("iframe").height(); // child height
					var wScale = wrapWidth / childWidth;
					var hScale = wrapHeight / childHeight;
					var scale = Math.min(wScale,hScale);  // get the lowest ratio
					$wrap.children("iframe").css({"transform": "scale("+scale+")", "transform-origin": "left top" });  // set scale
				};
				$(window).on("resize", iframeScaler);
				$(document).ready( iframeScaler);
			});
		});
		
		
		
	</script>
	
	<script>
	$('document').ready(function(){
		$(window).trigger('resize');
		
		$('.collapse').collapse()
		
	});
		</script>
	
	<link rel="shortcut icon" href="favicon.ico" />
</head>

<body class="t-Pac">

<?php
$page_id_cookie_banner = get_option('dettagli-id-cookie');
if (!$page_id_cookie_banner) $page_id_cookie_banner = get_option('dettagli-id-privacy');
?>
    
<div class="cookiebar hide u-background-80" aria-hidden="true">
    <p class="text-white">
        <?php echo __('This site uses technical, analytics and third-party cookies','italiawp2'); ?>.
        <?php echo __('By continuing to browse, you accept the use of cookies','italiawp2'); ?>.<br />
        <button data-accept="cookiebar" class="btn btn-info mr-2 btn-verde">
            <?php echo __('I accept','italiawp2'); ?>
        </button>
        <a href="<?php echo get_permalink($page_id_cookie_banner); ?>" class="btn btn-outline-info btn-trasp"><?php echo __('Cookie policy','italiawp2'); ?></a>
    </p>
</div>
    


    <header id="mainheader" class="u-background-50" style="background-color: #0059b3!important">
    <?php get_template_part('menu'); ?>
    </header>

    <main id="main_container">
        
    <?php if(!is_attachment()) italiawp2_create_breadcrumbs(); ?>
