<?php

get_header();

get_template_part( 'template-parts/main-loop' );

get_sidebar();
get_footer();
