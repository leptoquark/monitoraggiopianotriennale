<?php

get_header();

get_template_part( 'template-parts/archive-loop' );

get_sidebar();
get_footer();
